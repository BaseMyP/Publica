test_that("BaseMyP_obtener_catalogo valida origen y token correctamente", {
  # Valida que el repositorio sea una opcion valida
  expect_error(
    BaseMyP_obtener_catalogo(repositorio = "invalido"),
    regexp = "'arg' should be one of"
  )
  
  # Falla si se pide un repositorio privado/no publico sin pasar token
  expect_error(
    BaseMyP_obtener_catalogo(repositorio = "series_propias", token = NULL),
    regexp = "Se requiere un 'token' valido"
  )
  expect_error(
    BaseMyP_obtener_catalogo(repositorio = "transformaciones", token = ""),
    regexp = "Se requiere un 'token' valido"
  )
})

test_that("BaseMyP_obtener_catalogo descarga catalogo publico con estructura esperada", {
  testthat::skip_if_offline()
  
  # Descarga del catalogo publico
  catalogo <- tryCatch(
    BaseMyP_obtener_catalogo(repositorio = "publica"),
    error = function(e) e
  )
  
  # Si la API de GitHub tiene limite de tasa (rate limit) en el momento, salteamos
  if (inherits(catalogo, "error")) {
    testthat::skip("API de GitHub no disponible o límite de consultas alcanzado.")
  }
  
  expect_s3_class(catalogo, "data.frame")
  expect_true("serie_id" %in% names(catalogo))
  expect_true(nrow(catalogo) >= 0)
})