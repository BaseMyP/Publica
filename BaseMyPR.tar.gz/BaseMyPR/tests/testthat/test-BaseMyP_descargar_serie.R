test_that("BaseMyP_descargar_serie valida argumentos locales correctamente", {
  # Error si el origen no esta entre las opciones permitidas
  expect_error(
    BaseMyP_descargar_serie("serie_prueba_D", origen = "invalido"),
    regexp = "'arg' should be one of"
  )
  
  # Error si 'serie' esta vacio o no es caracter
  expect_error(
    BaseMyP_descargar_serie(character(0)),
    regexp = "debe ser un vector de caracteres no vacio"
  )
  
  expect_error(
    BaseMyP_descargar_serie(123),
    regexp = "debe ser un vector de caracteres no vacio"
  )
  
  # Error si se combinan distintas frecuencias (ej: _D y _M o _Q)
  expect_error(
    BaseMyP_descargar_serie(c("SECTOR/SERIE1_D", "SECTOR/SERIE2_M")),
    regexp = "No se puede combinar series de distinta frecuencia"
  )
  
  expect_error(
    BaseMyP_descargar_serie(c("SECTOR/SERIE1_Q", "SECTOR/SERIE2_M")),
    regexp = "No se puede combinar series de distinta frecuencia"
  )
  
  # Frecuencia anual y ubicacion intermedia
  expect_error(
    BaseMyP_descargar_serie(c(
      "DEUDA_PUBLICA/DEUDANETA_REAL_DIC1992_NSA_M_DISCONTINUADA",
      "ACTIVIDAD/PIB_REAL_NSA_A"
    )),
    regexp = "No se puede combinar series de distinta frecuencia"
  )
})

test_that("BaseMyP_descargar_serie falla ordenadamente con serie inexistente", {
  testthat::skip_if_offline()
  
  expect_error(
    BaseMyP_descargar_serie("serie_que_definitivamente_no_existe_xyz_123_D", origen = "publica"),
    regexp = "Error al descargar"
  )
})

test_that("BaseMyP_descargar_serie descarga y formatea correctamente una serie individual", {
  testthat::skip_if_offline()
  
  serie_test <- "DEPOSITOS/DEPUSDPRIV_NOMINALUSD_NSA_D"
  nombre_col <- sub(".*/", "", serie_test)
  
  df <- BaseMyP_descargar_serie(serie_test, origen = "publica")
  
  expect_s3_class(df, "data.frame")
  expect_true("fecha" %in% names(df))
  expect_true(nombre_col %in% names(df))
  expect_s3_class(df$fecha, "Date")
  expect_equal(ncol(df), 2)
})

test_that("BaseMyP_descargar_serie descarga y combina multiples series de igual frecuencia", {
  testthat::skip_if_offline()
  
  # Dos series diarias reales
  series_test <- c(
    "AGREGADOS/BASEMONETARIA_NOMINAL_NSA_D",
    "AGREGADOS/CIRC_ENTIDADES_NOMINAL_NSA_D"
  )
  col_names <- sub(".*/", "", series_test)
  
  df_multiple <- BaseMyP_descargar_serie(series_test, origen = "publica")
  
  expect_s3_class(df_multiple, "data.frame")
  expect_true("fecha" %in% names(df_multiple))
  expect_true(all(col_names %in% names(df_multiple)))
  expect_s3_class(df_multiple$fecha, "Date")
  
  # Verificar que las fechas esten ordenadas cronologicamente de forma ascendente
  expect_false(is.unsorted(df_multiple$fecha))
})