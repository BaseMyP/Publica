#' Obtener el catalogo de series de BaseMyP
#'
#' Descarga y procesa el archivo \code{catalogo.json} desde los repositorios
#' de BaseMyP en GitHub, devolviendo una tabla con el inventario de series disponibles.
#'
#' @param repositorio Caracter. Repositorio del cual obtener el catalogo.
#'   Opciones disponibles: \code{"publica"}, \code{"transformaciones"} o \code{"series_propias"}.
#'   Por defecto es \code{"publica"}.
#' @param token Caracter opcional. GitHub Personal Access Token (PAT). Es obligatorio
#'   para repositorios no publicos (\code{"transformaciones"} y \code{"series_propias"}),
#'   y opcional para \code{"publica"}.
#'
#' @return Un \code{data.frame} (o \code{tibble}) con la informacion de las series,
#'   incluyendo la columna \code{Carpeta} al inicio indicando la categoria o carpeta de origen.
#'
#' @importFrom httr GET add_headers stop_for_status content
#' @importFrom jsonlite fromJSON
#' @importFrom dplyr mutate %>%
#' @importFrom rlang .data
#'
#' @export
BaseMyP_obtener_catalogo <- function(repositorio = c("publica", "transformaciones", "series_propias", "agregados"), 
                             token = NULL) {
  
  repositorio <- match.arg(repositorio)
  
  # Mapeo del nombre del repositorio en GitHub
  repo_nombre <- switch(
    repositorio,
    "publica"          = "Publica",
    "transformaciones" = "Transformaciones",
    "series_propias"   = "Series_Propias",
    "agregados" = "Agregados"
  )
  
  url <- sprintf(
    "https://api.github.com/repos/BaseMyP/%s/contents/catalogo.json?ref=main",
    repo_nombre
  )
  
  # Headers base
  encabezados <- list(
    Accept       = "application/vnd.github.raw",
    `User-Agent` = "R-script-BaseMyP"
  )
  
  # Validacion y asignacion del token
  tiene_token <- !is.null(token) && nzchar(token)
  
  if (repositorio != "publica") {
    if (!tiene_token) {
      stop(
        sprintf("Se requiere un 'token' valido para acceder al repositorio: '%s'.", repositorio), 
        call. = FALSE
      )
    }
    encabezados$Authorization <- paste("Bearer", token)
  } else if (tiene_token) {
    encabezados$Authorization <- paste("Bearer", token)
  }
  
  # Peticion HTTP
  respuesta <- httr::GET(url, do.call(httr::add_headers, encabezados))
  httr::stop_for_status(respuesta)
  
  # Parseo y procesamiento
  contenido <- httr::content(respuesta, as = "text", encoding = "UTF-8")
  df <- jsonlite::fromJSON(contenido, simplifyDataFrame = TRUE)
  
  df %>%
    dplyr::mutate(Carpeta = basename(dirname(.data$raw_url)), .before = 1) %>%
    dplyr::mutate(serie_id = paste0(.data$Carpeta, "/", .data$serie_id)) %>%
    dplyr::select(-"Carpeta") %>%
    dplyr::arrange(.data$serie_id)
}