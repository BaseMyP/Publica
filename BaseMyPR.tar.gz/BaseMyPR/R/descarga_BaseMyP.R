#' Descargar series de tiempo desde los repositorios de BaseMyP
#'
#' Consulta y descarga una o más series en formato JSON desde los repositorios de GitHub
#' correspondientes y devuelve un data frame estructurado.
#'
#' @param serie Caracter o vector de caracteres. Nombre(s) o ruta(s) de la(s) serie(s)
#'   a descargar (sin extension .json). Si es un vector, todas deben compartir la misma frecuencia.
#' @param origen Caracter. Repositorio de origen. Puede ser \code{"publica"},
#'   \code{"series_propias"}, \code{"transformaciones"} o \code{"agregados"}.
#'   Por defecto es \code{"publica"}.
#' @param token Caracter opcional. GitHub Personal Access Token (PAT) para repositorios
#'   privados o para evitar los limites de tasa (rate limits) de la API.
#' @param tiempo_espera Numerico. Tiempo maximo de espera (timeout) en segundos. Por defecto 15.
#'
#' @return Un \code{tibble} o \code{data.frame} con la columna \code{fecha} y las columnas
#'   correspondientes a los valores de cada serie solicitada, ordenado por fecha.
#'
#' @importFrom httr GET add_headers timeout http_error status_code content
#' @importFrom jsonlite fromJSON
#' @importFrom dplyr filter select mutate rename arrange full_join %>%
#' @importFrom purrr reduce
#' @importFrom rlang .data :=
#' @importFrom utils URLencode
#'
#' @export
BaseMyP_descargar_serie <- function(serie, 
                                    origen = c("publica", "series_propias", "transformaciones", "agregados"), 
                                    token = NULL,
                                    tiempo_espera = 15) {
  
  if (!is.character(serie) || length(serie) == 0) {
    stop("El argumento 'serie' debe ser un vector de caracteres no vacio.", call. = FALSE)
  }
  
  # Helper para extraer la frecuencia (Q, M, D, A)
  extraer_frecuencia <- function(s) {
    # 1. Prioridad: Buscar al final del string (_Q, _M, _D, _A)
    frec_final <- sub(".*_([QMDA])$", "\\1", s)
    if (frec_final %in% c("Q", "M", "D", "A")) {
      return(frec_final)
    }
    
    # 2. Si no esta al final, buscar en el medio (_Q_, _M_, _D_, _A_)
    frec_medio <- sub(".*_([QMDA])_.*$", "\\1", s)
    if (frec_medio %in% c("Q", "M", "D", "A")) {
      return(frec_medio)
    }
    
    NA_character_
  }
  
  # Validar homogeneidad de frecuencias si se solicita mas de una serie
  if (length(serie) > 1) {
    frecuencias <- vapply(serie, extraer_frecuencia, character(1), USE.NAMES = FALSE)
    
    if (any(is.na(frecuencias)) || length(unique(frecuencias)) > 1) {
      stop("No se puede combinar series de distinta frecuencia", call. = FALSE)
    }
  }
  
  origen <- match.arg(origen)
  
  # Funcion auxiliar para descargar y procesar una serie individual
  descargar_individual <- function(s) {
    
    ruta_archivo <- utils::URLencode(paste0(s, ".json"))
    
    if (origen == "publica") {
      url_completa <- paste0("https://raw.githubusercontent.com/BaseMyP/Publica/main/", ruta_archivo)
      headers_lista <- list(`User-Agent` = "R-script-BaseMyP", Connection = "close")
    } else {
      repos_base <- c(
        series_propias   = "https://api.github.com/repos/BaseMyP/Series_Propias/contents/",
        transformaciones = "https://api.github.com/repos/BaseMyP/Transformaciones/contents/",
        agregados        = "https://api.github.com/repos/BaseMyP/Agregados/contents/"
      )
      url_completa <- paste0(repos_base[origen], ruta_archivo, "?ref=main")
      headers_lista <- list(
        Accept = "application/vnd.github.raw",
        `User-Agent` = "R-script-BaseMyP", 
        Connection = "close"
      )
    }
    
    if (!is.null(token) && nzchar(token)) {
      headers_lista$Authorization <- paste("Bearer", token)
    }
    
    respuesta <- httr::GET(
      url = url_completa, 
      do.call(httr::add_headers, headers_lista),
      httr::timeout(tiempo_espera)
    )
    
    if (httr::http_error(respuesta)) {
      stop(sprintf(
        "Error al descargar '%s' desde '%s' [Status %s]: Verifique el nombre de la serie o el token ingresado.",
        s, origen, httr::status_code(respuesta)
      ), call. = FALSE)
    }
    
    datos_json <- jsonlite::fromJSON(httr::content(respuesta, as = "text", encoding = "UTF-8"))
    nombre <- sub(".*/", "", s)
    
    datos_json$observaciones %>%
      dplyr::filter(.data$realtime_end == "9999-12-31") %>%
      dplyr::select("fecha", "valor") %>%
      dplyr::mutate(fecha = as.Date(.data$fecha)) %>%
      dplyr::rename(!!nombre := "valor")
  }
  
  # Caso 1: Un solo elemento
  if (length(serie) == 1) {
    return(descargar_individual(serie))
  }
  
  # Caso 2: Vector de series
  lista_dfs <- lapply(serie, descargar_individual)
  
  df_resultado <- purrr::reduce(lista_dfs, function(x, y) {
    dplyr::full_join(x, y, by = "fecha")
  }) %>%
    dplyr::arrange(.data$fecha)
  
  return(df_resultado)
}