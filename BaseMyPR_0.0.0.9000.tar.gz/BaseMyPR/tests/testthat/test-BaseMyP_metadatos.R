test_that("BaseMyP_metadatos valida argumentos locales", {
  expect_error(
    BaseMyP_metadatos("serie_prueba", origen = "invalido"),
    regexp = "'arg' should be one of"
  )
})

test_that("BaseMyP_metadatos descarga y devuelve un tibble para serie publica", {
  testthat::skip_if_offline()
  
  # Probamos con la misma serie de prueba que usas en descargar_serie
  # Reemplaza 'nombre_serie_real' por una serie real de 'publica'
  meta <- BaseMyP_metadatos("DEPOSITOS/DEPUSDPRIV_NOMINALUSD_NSA_D", origen = "publica")
  # Verificamos clase y columnas
  expect_s3_class(meta, "data.frame")
  expect_named(meta, c("campo", "valor"))
  
  # Verificamos que traiga filas de metadatos (mayor a cero)
  expect_gt(nrow(meta), 0)
})
