test_that("BaseMyP_descargar_serie valida argumentos locales correctamente", {
  # Error si el origen no esta entre las opciones permitidas
  expect_error(
    BaseMyP_descargar_serie("serie_prueba", origen = "invalido"),
    regexp = "'arg' should be one of"
  )
})

test_that("BaseMyP_descargar_serie falla ordenadamente con serie inexistente", {
  # Saltear si no hay conexion a internet
  testthat::skip_if_offline()
  
  # Serie inexistente en repo publico deberia arrojar un error HTTP
  expect_error(
    BaseMyP_descargar_serie("serie_que_definitivamente_no_existe_xyz_123", origen = "publica"),
    regexp = "Error al descargar"
  )
})

test_that("BaseMyP_descargar_serie descarga y formatea correctamente una serie publica", {
  testthat::skip_if_offline()
  
  # Cambia 'nombre_serie_real' por el nombre de una serie que exista en el repo publica
  df <- BaseMyP_descargar_serie("DEPOSITOS/DEPUSDPRIV_NOMINALUSD_NSA_D", origen = "publica")
  expect_s3_class(df, "data.frame")
  expect_true("fecha" %in% names(df))
  expect_s3_class(df$fecha, "Date")
})