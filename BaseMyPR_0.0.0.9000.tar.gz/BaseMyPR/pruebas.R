library(usethis)
create_package(".")

library(usethis)

# 1. Crea el archivo DESCRIPTION con el nombre del directorio actual
use_description()

# 2. Crea el archivo NAMESPACE inicial
use_namespace()

# 3. Crea la carpeta R/ para almacenar las funciones
dir.create("R", showWarnings = FALSE)

# 4. Configura .Rbuildignore para excluir archivos de Git y de RStudio
use_build_ignore(c("[.]Rproj$", "^[.]Rproj[.]user$", "^[.]git$", "^[.]gitignore$"))

usethis::use_r("descarga_BaseMyP")
usethis::use_r("catalogo_BaseMyP")

# 1. Declarar las dependencias en DESCRIPTION
usethis::use_package("httr")
usethis::use_package("jsonlite")
usethis::use_package("dplyr")
usethis::use_package("rlang")

# 2. Generar el archivo NAMESPACE y las paginas de ayuda (.Rd)
devtools::document()

# 3. Probar la funcion en memoria
devtools::load_all()

# 4. Verificar que no haya warnings ni errores de paquete
devtools::check()

# Testthat
usethis::use_testthat()
usethis::use_test("BaseMyP_descargar_serie")
usethis::use_test("BaseMyP_obtener_catalogo")
devtools::test()