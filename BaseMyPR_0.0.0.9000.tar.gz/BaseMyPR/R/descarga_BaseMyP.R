#' Descargar series de tiempo desde los repositorios de BaseMyP
#'
#' Consulta y descarga una serie en formato JSON desde los repositorios de GitHub
#' correspondientes y devuelve un data frame estructurado.
#'
#' @param serie Caracter. Nombre o ruta de la serie a descargar (sin extension .json).
#' @param origen Caracter. Repositorio de origen. Puede ser \code{"publica"},
#'   \code{"series_propias"}, \code{"transformaciones"} o \code{"agregados"}.
#'   Por defecto es \code{"publica"}.
#' @param token Caracter opcional. GitHub Personal Access Token (PAT) para repositorios
#'   privados o para evitar los limites de tasa (rate limits) de la API.
#' @param tiempo_espera Numerico. Tiempo maximo de espera (timeout) en segundos. Por defecto 15.
#'
#' @return Un \code{tibble} o \code{data.frame} con la columna \code{fecha} y el valor de la serie
#'   nombrado segun el identificador provisto.
#'
#' @importFrom httr GET add_headers timeout http_error status_code content
#' @importFrom jsonlite fromJSON
#' @importFrom dplyr filter select mutate rename %>%
#' @importFrom rlang .data :=
#' @importFrom utils URLencode
#'
#' @export
BaseMyP_descargar_serie <- function(serie, 
                            origen = c("publica", "series_propias", "transformaciones", "agregados"), 
                            token = NULL,
                            tiempo_espera = 15) {
  
  origen <- match.arg(origen)
  
  # Mapeo a los endpoints de contenidos de la API de GitHub
  repos_base <- c(
    publica          = "https://api.github.com/repos/BaseMyP/Publica/contents/",
    series_propias   = "https://api.github.com/repos/BaseMyP/Series_Propias/contents/",
    transformaciones = "https://api.github.com/repos/BaseMyP/Transformaciones/contents/",
    agregados        = "https://api.github.com/repos/BaseMyP/Agregados/contents/"
  )
  
  # Asegura el encodeo adecuado si la ruta incluye subdirectorios o espacios
  ruta_archivo <- utils::URLencode(paste0(serie, ".json"))
  url_completa <- paste0(repos_base[origen], ruta_archivo, "?ref=main")
  
  # Headers obligatorios para la API de GitHub
  headers_lista <- list(
    Accept       = "application/vnd.github.raw",
    `User-Agent` = "R-script-BaseMyP",
    Connection   = "close"
  )
  
  # Header de autorizacion si se provee token
  if (!is.null(token) && nzchar(token)) {
    headers_lista$Authorization <- paste("Bearer", token)
  }
  
  # Peticion HTTP
  respuesta <- httr::GET(
    url = url_completa, 
    do.call(httr::add_headers, headers_lista),
    httr::timeout(tiempo_espera)
  )
  
  # Validar status HTTP
  if (httr::http_error(respuesta)) {
    stop(sprintf(
      "Error al descargar '%s' desde '%s' [Status %s]: Verifique el nombre de la serie o el token ingresado.",
      serie, origen, httr::status_code(respuesta)
    ), call. = FALSE)
  }
  
  datos_json <- jsonlite::fromJSON(httr::content(respuesta, as = "text", encoding = "UTF-8"))
  nombre <- sub(".*/", "", serie)
  
  df <- datos_json$observaciones %>%
    dplyr::filter(.data$realtime_end == "9999-12-31") %>%
    dplyr::select("fecha", "valor") %>%
    dplyr::mutate(fecha = as.Date(.data$fecha)) %>%
    dplyr::rename(!!nombre := "valor")
  
  return(df)
}