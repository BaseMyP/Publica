#' Obtener los metadatos de una serie de BaseMyP
#'
#' Consulta y descarga los metadatos asociados a una serie en formato JSON desde
#' los repositorios de GitHub de BaseMyP y los devuelve estructurados como un data frame.
#'
#' @param serie Caracter. Nombre o ruta de la serie (sin extension .json).
#' @param origen Caracter. Repositorio de origen. Puede ser \code{"publica"},
#'   \code{"series_propias"}, \code{"transformaciones"} o \code{"agregados"}.
#'   Por defecto es \code{"publica"}.
#' @param token Caracter opcional. GitHub Personal Access Token (PAT).
#' @param tiempo_espera Numerico. Tiempo maximo de espera en segundos. Por defecto 15.
#'
#' @return Un \code{data.frame} (o \code{tibble}) de una fila con las propiedades y
#'   atributos de los metadatos de la serie.
#'
#' @importFrom httr GET add_headers timeout http_error status_code content
#' @importFrom jsonlite fromJSON
#' @importFrom tibble as_tibble
#' @importFrom utils URLencode
#'
#' @export
BaseMyP_metadatos <- function(serie, 
                              origen = c("publica", "series_propias", "transformaciones", "agregados"), 
                              token = NULL,
                              tiempo_espera = 15) {
  
  origen <- match.arg(origen)
  
  # Mapeo a los endpoints de contenidos de la API de GitHub
  repos_base <- c(
    publica          = "https://api.github.com/repos/BaseMyP/Publica/contents/",
    series_propias   = "https://api.github.com/repos/BaseMyP/Series_Propias/contents/",
    transformaciones = "https://api.github.com/repos/BaseMyP/Transformaciones/contents/",
    agregados        = "https://api.github.com/repos/BaseMyP/Agregados/contents/"
  )
  
  # Asegura el encodeo adecuado de la ruta
  ruta_archivo <- utils::URLencode(paste0(serie, ".json"))
  url_completa <- paste0(repos_base[origen], ruta_archivo, "?ref=main")
  
  # Headers obligatorios para la API de GitHub
  headers_lista <- list(
    Accept       = "application/vnd.github.raw",
    `User-Agent` = "R-script-BaseMyP",
    Connection   = "close"
  )
  
  # Header de autorizacion si se provee token
  if (!is.null(token) && nzchar(token)) {
    headers_lista$Authorization <- paste("Bearer", token)
  }
  
  # Peticion HTTP
  respuesta <- httr::GET(
    url = url_completa, 
    do.call(httr::add_headers, headers_lista),
    httr::timeout(tiempo_espera)
  )
  
  # Validar status HTTP
  if (httr::http_error(respuesta)) {
    stop(sprintf(
      "Error al descargar metadatos de '%s' desde '%s' [Status %s]: Verifique el nombre de la serie o el token ingresado.",
      serie, origen, httr::status_code(respuesta)
    ), call. = FALSE)
  }
  
  datos_json <- jsonlite::fromJSON(httr::content(respuesta, as = "text", encoding = "UTF-8"))
  
  # Convertir la lista de metadatos a data.frame (tibble de 1 fila)
  # Si algún campo es NULL, lo reemplazamos por NA para evitar errores al vectorizar
  meta_raw <- as.list(datos_json$metadatos)
  
  df_meta <- tibble::tibble(
    campo = names(meta_raw),
    valor = vapply(meta_raw, function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(x, collapse = ", ")
    }, character(1))
  )
  
  return(df_meta)
}