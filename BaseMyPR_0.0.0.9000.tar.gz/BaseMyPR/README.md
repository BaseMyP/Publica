
<!-- README.md is generated from README.Rmd. Please edit that file -->

# BaseMyPR

<!-- badges: start -->
<!-- badges: end -->

El objetivo de **BaseMyPR** es facilitar la consulta, exploración y
descarga de series de tiempo y metadatos alojados en los repositorios de
**BaseMyP** en GitHub.

## Instalación

Podés instalar la versión en desarrollo de **BaseMyPR** desde
[GitHub](https://github.com/BaseMyP/BaseMyPR) mediante:

``` r
# install.packages("remotes")
remotes::install_github("BaseMyP/BaseMyPR")
```

## Uso y ejemplos

``` r
library(BaseMyPR)
```

### 1. Explorar el catálogo de series disponibles

La función `BaseMyP_obtener_catalogo()` descarga el inventario
consolidado de series para un repositorio determinado (por defecto
`"publica"`).

``` r
# Descarga del catálogo público
catalogo <- BaseMyP_obtener_catalogo(repositorio = "publica")

# Vista preliminar de las primeras columnas
head(catalogo[, c("Carpeta", "serie_id", "descripcion")])
```

> **Nota:** Para consultar repositorios privados (`"series_propias"` o
> `"transformaciones"`), es necesario proveer un GitHub Personal Access
> Token mediante el argumento `token = "TU_TOKEN"` o leyendo una
> variable de entorno.

------------------------------------------------------------------------

### 2. Consultar metadatos de una serie

Con `BaseMyP_metadatos()` podés consultar la ficha técnica y descriptiva
de una serie en formato clave-valor:

``` r
# Obtener metadatos en formato tabla (campo / valor)
meta_serie <- BaseMyP_metadatos(
  serie = "nombre_de_la_serie", 
  origen = "publica"
)

print(meta_serie)
```

------------------------------------------------------------------------

### 3. Descargar observaciones de una serie

`BaseMyP_descargar_serie()` descarga el archivo JSON correspondiente,
filtra los registros vigentes y retorna un `tibble` con la columna
`fecha` tipada como `Date` y el valor de la serie nombrado con el
identificador solicitado:

``` r
# Descarga de la serie temporal
df_serie <- BaseMyP_descargar_serie(
  serie = "nombre_de_la_serie", 
  origen = "publica"
)

head(df_serie)
```

------------------------------------------------------------------------

### Autenticación para repositorios privados

Dado que cada repositorio privado requiere un token específico, se puede
elegir entre cargarlo manualmente o configurar un Personal Access Token
(PAT) diferenciado en el archivo `.Renviron` local.

**Carga Manual del Token**

``` r
token_transformaciones = "" # Ingresar aquí el token
token_series_propias = "" # Ingresar aquí el token

# Ejemplo 1: Consultar catálogo de Transformaciones
cat_transf <- BaseMyP_obtener_catalogo(
  repositorio = "transformaciones",
  token = token_transformaciones
)

# Ejemplo 2: Descargar serie desde Series Propias
serie_propia <- BaseMyP_descargar_serie(
  serie = "mi_serie_privada",
  origen = "series_propias",
  token = token_series_propias
)

# Ejemplo 3: Consultar metadatos de Transformaciones
meta_transf <- BaseMyP_metadatos(
  serie = "mi_serie_transformada",
  origen = "transformaciones",
  token = token_transformaciones
)
```

**Configurar un Personal Access Token (PAT)**

``` bash
# Archivo ~/.Renviron (editable con usethis::edit_r_environ())
GITHUB_PAT_TRANSFORMACIONES="ghp_token_para_transformaciones"
GITHUB_PAT_SERIES_PROPIAS="ghp_token_para_series_propias"
```

Luego podés invocarlos directamente en las funciones según el origen
correspondiente:

``` r
# Ejemplo 1: Consultar catálogo de Transformaciones
cat_transf <- BaseMyP_obtener_catalogo(
  repositorio = "transformaciones",
  token = Sys.getenv("GITHUB_PAT_TRANSFORMACIONES")
)

# Ejemplo 2: Descargar serie desde Series Propias
serie_propia <- BaseMyP_descargar_serie(
  serie = "mi_serie_privada",
  origen = "series_propias",
  token = Sys.getenv("GITHUB_PAT_SERIES_PROPIAS")
)

# Ejemplo 3: Consultar metadatos de Transformaciones
meta_transf <- BaseMyP_metadatos(
  serie = "mi_serie_transformada",
  origen = "transformaciones",
  token = Sys.getenv("GITHUB_PAT_TRANSFORMACIONES")
)
```
