# BaseMyP Python Client

Cliente en Python para descargar y consultar series de tiempo desde los repositorios de BaseMyP en GitHub.

## Instalación
```bash
pip install basemypPy.tar.gz