import os
import re
from functools import reduce
import pandas as pd
import requests

REPOS_BASE = {
    "publica": "https://api.github.com/repos/BaseMyP/Publica/contents/",
    "series_propias": "https://api.github.com/repos/BaseMyP/Series_Propias/contents/",
    "transformaciones": "https://api.github.com/repos/BaseMyP/Transformaciones/contents/",
    "agregados": "https://api.github.com/repos/BaseMyP/Agregados/contents/",
}


def BaseMyP_metadatos(
    serie: str,
    origen: str = "publica",
    token: str = None,
    tiempo_espera: int = 15,
) -> pd.DataFrame:
    """Obtener los metadatos de una serie de BaseMyP."""
    if origen not in REPOS_BASE:
        raise ValueError(f"El origen debe ser uno de: {list(REPOS_BASE.keys())}")

    url_completa = f"{REPOS_BASE[origen]}{serie}.json?ref=main"

    headers = {
        "Accept": "application/vnd.github.raw",
        "User-Agent": "Python-script-BaseMyP",
        "Connection": "close",
    }

    if token:
        headers["Authorization"] = f"Bearer {token}"

    respuesta = requests.get(
        url_completa, headers=headers, timeout=tiempo_espera
    )

    if not respuesta.ok:
        raise RuntimeError(
            f"Error al descargar metadatos de '{serie}' desde '{origen}' "
            f"[Status {respuesta.status_code}]: Verifique el nombre de la serie o el token ingresado."
        )

    datos_json = respuesta.json()
    meta_raw = datos_json.get("metadatos", {})

    campos = []
    valores = []

    for k, v in meta_raw.items():
        campos.append(k)
        if v is None or (isinstance(v, (list, tuple)) and len(v) == 0):
            valores.append(None)
        elif isinstance(v, list):
            valores.append(", ".join(map(str, v)))
        else:
            valores.append(str(v))

    return pd.DataFrame({"campo": campos, "valor": valores})


def BaseMyP_obtener_catalogo(
    repositorio: str = "publica", token: str = None
) -> pd.DataFrame:
    """Obtener el catálogo de series de BaseMyP."""
    repo_map = {
        "publica": "Publica",
        "transformaciones": "Transformaciones",
        "series_propias": "Series_Propias",
        "agregados": "Agregados",
    }

    if repositorio not in repo_map:
        raise ValueError(
            f"El repositorio debe ser uno de: {list(repo_map.keys())}"
        )

    repo_nombre = repo_map[repositorio]
    url = f"https://api.github.com/repos/BaseMyP/{repo_nombre}/contents/catalogo.json?ref=main"

    headers = {
        "Accept": "application/vnd.github.raw",
        "User-Agent": "Python-script-BaseMyP",
    }

    tiene_token = bool(token)

    if repositorio != "publica" and not tiene_token:
        raise ValueError(
            f"Se requiere un 'token' válido para acceder al repositorio: '{repositorio}'."
        )

    if tiene_token:
        headers["Authorization"] = f"Bearer {token}"

    respuesta = requests.get(url, headers=headers)
    respuesta.raise_for_status()

    df = pd.DataFrame(respuesta.json())

    def extraer_carpeta(url_str):
        if pd.isna(url_str):
            return ""
        dirname = os.path.dirname(str(url_str))
        return os.path.basename(dirname)

    df["Carpeta"] = df["raw_url"].apply(extraer_carpeta)
    df["serie_id"] = df["Carpeta"] + "/" + df["serie_id"]

    df = df.drop(columns=["Carpeta"])
    df = df.sort_values(by="serie_id").reset_index(drop=True)

    return df


def BaseMyP_descargar_serie(
    serie,
    origen: str = "publica",
    token: str = None,
    tiempo_espera: int = 15,
) -> pd.DataFrame:
    """Descargar series de tiempo desde los repositorios de BaseMyP."""
    if isinstance(serie, str):
        serie = [serie]

    if not isinstance(serie, list) or len(serie) == 0:
        raise ValueError(
            "El argumento 'serie' debe ser un string o una lista de strings no vacía."
        )

    def extraer_frecuencia(s):
        match_final = re.search(r"_([QMDA])$", s)
        if match_final:
            return match_final.group(1)

        match_medio = re.search(r"_([QMDA])_", s)
        if match_medio:
            return match_medio.group(1)

        return None

    if len(serie) > 1:
        frecuencias = [extraer_frecuencia(s) for s in serie]
        if any(f is None for f in frecuencias) or len(set(frecuencias)) > 1:
            raise ValueError(
                "No se puede combinar series de distinta frecuencia"
            )

    validos_origen = ["publica", "series_propias", "transformaciones", "agregados"]
    if origen not in validos_origen:
        raise ValueError(f"El origen debe ser uno de: {validos_origen}")

    def descargar_individual(s):
        ruta_archivo = f"{s}.json"

        if origen == "publica":
            url_completa = f"https://raw.githubusercontent.com/BaseMyP/Publica/main/{ruta_archivo}"
            headers = {
                "User-Agent": "Python-script-BaseMyP",
                "Connection": "close",
            }
        else:
            url_completa = f"{REPOS_BASE[origen]}{ruta_archivo}?ref=main"
            headers = {
                "Accept": "application/vnd.github.raw",
                "User-Agent": "Python-script-BaseMyP",
                "Connection": "close",
            }

        if token:
            headers["Authorization"] = f"Bearer {token}"

        respuesta = requests.get(
            url_completa, headers=headers, timeout=tiempo_espera
        )

        if not respuesta.ok:
            raise RuntimeError(
                f"Error al descargar '{s}' desde '{origen}' [Status {respuesta.status_code}]: "
                "Verifique el nombre de la serie o el token ingresado."
            )

        datos_json = respuesta.json()
        nombre = s.split("/")[-1]

        obs = pd.DataFrame(datos_json.get("observaciones", []))
        if obs.empty:
            return pd.DataFrame(columns=["fecha", nombre])

        obs = obs[obs["realtime_end"] == "9999-12-31"]
        obs = obs[["fecha", "valor"]].copy()

        obs["fecha"] = pd.to_datetime(obs["fecha"]).dt.date
        obs = obs.rename(columns={"valor": nombre})

        return obs

    if len(serie) == 1:
        return descargar_individual(serie[0])

    lista_dfs = [descargar_individual(s) for s in serie]

    df_resultado = reduce(
        lambda left, right: pd.merge(left, right, on="fecha", how="outer"),
        lista_dfs,
    )
    df_resultado = df_resultado.sort_values(by="fecha").reset_index(drop=True)

    return df_resultado